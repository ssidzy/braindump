const path = require('path');
const http = require('http');
const express = require('express');
const { WebSocketServer } = require('ws');
const { v4: uuidv4 } = require('uuid');

const PORT = process.env.PORT || 8080;
const users = {
  sidzy: { password: 'sid06', label: 'Sidzy' },
  sandy: { password: 'san22', label: 'Sandy' },
  sonzy: { password: 'son27', label: 'Sonzy' },
  yashas: { password: 'yas03', label: 'Yashas' }
};

const sessions = new Map();
const userTokens = new Map();
const clients = new Map();
let currentScreenSharer = null;

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.post('/api/login', (req, res) => {
  const { username, password } = req.body || {};

  if (!username || !password) {
    return res.status(400).json({ error: 'Missing credentials' });
  }

  const record = users[username];
  if (!record || record.password !== password) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }

  if (!clients.has(username) && clients.size >= 3) {
    return res.status(403).json({ error: 'Meeting is full' });
  }

  if (userTokens.has(username)) {
    const staleToken = userTokens.get(username);
    sessions.delete(staleToken);
  }

  const token = uuidv4();
  sessions.set(token, username);
  userTokens.set(username, token);

  res.json({ token, username, label: record.label });
});

const server = http.createServer(app);
const wss = new WebSocketServer({ server, path: '/ws' });

function noop() {}

const HEARTBEAT_INTERVAL_MS = 30000;

function markAlive() {
  this.isAlive = true;
}

const heartbeatInterval = setInterval(() => {
  wss.clients.forEach((client) => {
    if (client.isAlive === false) {
      client.terminate();
      return;
    }
    client.isAlive = false;
    client.ping(noop);
  });
}, HEARTBEAT_INTERVAL_MS);

wss.on('close', () => {
  clearInterval(heartbeatInterval);
});

function broadcast(payload, excludeUsername) {
  const message = JSON.stringify(payload);
  for (const [name, socket] of clients.entries()) {
    if (socket.readyState === socket.OPEN && name !== excludeUsername) {
      socket.send(message);
    }
  }
}

function sendTo(target, payload) {
  const socket = clients.get(target);
  if (!socket || socket.readyState !== socket.OPEN) {
    return;
  }
  socket.send(JSON.stringify(payload));
}

wss.on('connection', (ws) => {
  ws.isAlive = true;
  ws.on('pong', markAlive);
  let authenticatedUser = null;

  ws.on('message', (raw) => {
    let data;
    try {
      data = JSON.parse(raw.toString());
    } catch (error) {
      ws.send(JSON.stringify({ type: 'error', error: 'Invalid message format' }));
      return;
    }

    if (data.type === 'auth') {
      const token = data.token;
      const username = token && sessions.get(token);
      if (!username) {
        ws.send(JSON.stringify({ type: 'auth-denied', reason: 'Invalid session' }));
        ws.close(4001, 'Invalid session');
        return;
      }

      const currentToken = userTokens.get(username);
      if (currentToken !== token) {
        ws.send(JSON.stringify({ type: 'auth-denied', reason: 'Session superseded' }));
        ws.close(4002, 'Session superseded');
        return;
      }

      if (!clients.has(username) && clients.size >= 3) {
        ws.send(JSON.stringify({ type: 'auth-denied', reason: 'meeting-full' }));
        ws.close(4004, 'Meeting full');
        return;
      }

      if (clients.has(username)) {
        const existing = clients.get(username);
        if (existing.readyState === existing.OPEN) {
          existing.send(JSON.stringify({ type: 'forced-disconnect', reason: 'New login detected' }));
        }
        existing.close(4003, 'Duplicate connection');
      }

      authenticatedUser = username;
      clients.set(username, ws);

      const others = Array.from(clients.keys()).filter((name) => name !== username);
      ws.send(JSON.stringify({
        type: 'auth-success',
        user: username,
        peers: others,
        screenSharer: currentScreenSharer
      }));

      broadcast({ type: 'peer-joined', user: username }, username);
      return;
    }

    if (!authenticatedUser) {
      ws.send(JSON.stringify({ type: 'error', error: 'Not authenticated' }));
      return;
    }

    switch (data.type) {
      case 'webrtc-offer':
      case 'webrtc-answer':
      case 'ice-candidate': {
        const { to } = data;
        if (!to || !clients.has(to)) {
          return;
        }
        sendTo(to, {
          type: data.type,
          from: authenticatedUser,
          payload: data.payload
        });
        break;
      }
      case 'screen-share-start': {
        if (currentScreenSharer && currentScreenSharer !== authenticatedUser) {
          ws.send(JSON.stringify({ type: 'screen-share-denied', owner: currentScreenSharer }));
          break;
        }
        currentScreenSharer = authenticatedUser;
        broadcast({ type: 'screen-share-start', user: authenticatedUser });
        break;
      }
      case 'screen-share-stop': {
        if (currentScreenSharer === authenticatedUser) {
          currentScreenSharer = null;
          broadcast({ type: 'screen-share-stop', user: authenticatedUser });
        }
        break;
      }
      default:
        ws.send(JSON.stringify({ type: 'error', error: 'Unsupported message type' }));
    }
  });

  ws.on('close', () => {
    ws.removeListener('pong', markAlive);
    if (!authenticatedUser) {
      return;
    }
    clients.delete(authenticatedUser);

    if (currentScreenSharer === authenticatedUser) {
      currentScreenSharer = null;
      broadcast({ type: 'screen-share-stop', user: authenticatedUser }, authenticatedUser);
    }

    broadcast({ type: 'peer-left', user: authenticatedUser }, authenticatedUser);
  });

  ws.on('error', () => {
    ws.close(1011, 'WebSocket error');
  });
});

server.listen(PORT, () => {
  // eslint-disable-next-line no-console
  console.log(`Server listening on port ${PORT}`);
});
