const STORAGE_KEY = 'tricall.session';
const MAX_PARTICIPANTS = 3;
const CAMERA_MAX_BITRATE = 1800000;
const SCREEN_MAX_BITRATE = 6500000;
const RECOVERY_TIMEOUT_MS = 6000;
const ICE_RESTART_THROTTLE_MS = 8000;
const SCREEN_MAX_FPS = 60;
const CAMERA_MAX_FPS = 30;
const LABELS = {
	sidzy: 'Sidzy',
	sandy: 'Sandy',
	sonzy: 'Sonzy',
	yashas: 'Yashas'
};

function readSession() {
	try {
		return JSON.parse(localStorage.getItem(STORAGE_KEY));
	} catch (error) {
		return null;
	}
}

function clearSession() {
	localStorage.removeItem(STORAGE_KEY);
}

function labelFor(user) {
	return LABELS[user] || user;
}

const meetingShell = document.querySelector('.meeting-shell');
const screenVideo = document.getElementById('screen-video');
const screenPlaceholder = document.getElementById('screen-placeholder');
const screenIndicator = document.getElementById('screen-indicator');
const toggleAudioBtn = document.getElementById('toggle-audio');
const toggleVideoBtn = document.getElementById('toggle-video');
const toggleScreenBtn = document.getElementById('toggle-screen');
const toggleFullscreenBtn = document.getElementById('toggle-fullscreen');
const leaveBtn = document.getElementById('leave-call');

const sharingPeek = document.getElementById('sharing-peek');
const sharingPeekGrid = sharingPeek.querySelector('.peek-grid');
const sharingPeekEmpty = sharingPeek.querySelector('.peek-empty');
const sharingPeekHeader = sharingPeek.querySelector('.peek-header');
const supportsDocumentPiP = 'documentPictureInPicture' in window;
const overlayEnabled = !supportsDocumentPiP;

if (!overlayEnabled) {
	sharingPeek.style.display = 'none';
}

const slots = Array.from(document.querySelectorAll('.participant-tile')).map((element) => {
	const video = element.querySelector('video');
	const placeholder = element.querySelector('.video-placeholder');
	const name = element.querySelector('.name');
	const status = element.querySelector('.status-dot');

	placeholder.textContent = 'Seat open';
	placeholder.style.display = 'flex';
	name.textContent = 'Seat available';
	element.classList.add('offline');
	status.classList.add('offline');

	return {
		element,
		video,
		placeholder,
		name,
		status,
		user: null
	};
});

const slotByUser = new Map();
const remoteStreams = new Map();
let pipWindow = null;
let pipRoot = null;
let pipEmptyMessage = null;
let pipClosing = false;
let pipSuppressed = false;
const peerRecoveryTimers = new Map();
const peerRestartLocks = new Map();

function setTrackContentHint(track, hint) {
	if (!track || !('contentHint' in track)) {
		return;
	}
	try {
		track.contentHint = hint;
	} catch (error) {
		console.warn('Failed to set content hint:', error);
	}
}

async function applyTrackFrameRate(track, fps) {
	if (!track || typeof track.applyConstraints !== 'function') {
		return;
	}
	try {
		await track.applyConstraints({ frameRate: { ideal: fps, max: fps } });
	} catch (error) {
		console.warn('Frame rate constraint rejected:', error);
	}
}

function tuneSenderForTrack(sender, track, options) {
	if (!sender || typeof sender.getParameters !== 'function') {
		return;
	}

	const params = sender.getParameters();
	if (!params.encodings || params.encodings.length === 0) {
		params.encodings = [{}];
	}

	const encoding = params.encodings[0];
	if (options.maxBitrate) {
		encoding.maxBitrate = options.maxBitrate;
	}
	if (options.maxFramerate) {
		encoding.maxFramerate = options.maxFramerate;
	}
	if (options.priority) {
		encoding.priority = options.priority;
	}
	if (options.scaleResolutionDownBy) {
		encoding.scaleResolutionDownBy = options.scaleResolutionDownBy;
	}
	if (options.degradationPreference) {
		params.degradationPreference = options.degradationPreference;
	}

	try {
		sender.setParameters(params).catch((error) => {
			console.warn('Failed to tune sender parameters:', error);
		});
	} catch (error) {
		console.warn('setParameters rejected:', error);
	}

	if (options.contentHint) {
		setTrackContentHint(track, options.contentHint);
	}
}

function clearPeerRecovery(user) {
	const timer = peerRecoveryTimers.get(user);
	if (timer) {
		window.clearTimeout(timer);
		peerRecoveryTimers.delete(user);
	}
	peerRestartLocks.delete(user);
}

function schedulePeerRecovery(user, action) {
	clearPeerRecovery(user);
	const timer = window.setTimeout(() => {
		peerRecoveryTimers.delete(user);
		action();
	}, RECOVERY_TIMEOUT_MS);
	peerRecoveryTimers.set(user, timer);
}

async function attemptIceRestart(user) {
	const peerState = peerConnections.get(user);
	if (!peerState) {
		return;
	}

	const lastAttempt = peerRestartLocks.get(user);
	const now = Date.now();
	if (lastAttempt && now - lastAttempt < ICE_RESTART_THROTTLE_MS) {
		return;
	}
	peerRestartLocks.set(user, now);

	try {
		peerState.restartingIce = true;
		peerState.makingOffer = true;
		peerState.pc.restartIce();
		await peerState.pc.setLocalDescription(await peerState.pc.createOffer());
		sendToSocket({ type: 'webrtc-offer', to: user, payload: peerState.pc.localDescription });
	} catch (error) {
		console.error('ICE restart failed:', error);
	} finally {
		peerState.restartingIce = false;
		peerState.makingOffer = false;
	}
}

let socket;
let localUser = null;
let localStream = null;
let screenStream = null;
const peerConnections = new Map();
const screenSenders = new Map();
const state = {
	audioEnabled: true,
	videoEnabled: true,
	screenShareActive: false,
	activeScreenSharer: null,
	shuttingDown: false
};

const fullscreenSupport = Boolean(
	document.fullscreenEnabled ||
	document.webkitFullscreenEnabled ||
	document.msFullscreenEnabled
);

const session = readSession();
if (!session?.token) {
	window.location.replace('/');
}

boot();

async function boot() {
	try {
		await initLocalMedia();
	} catch (error) {
		alert('Camera or microphone access is required to join.');
		clearSession();
		window.location.replace('/');
		return;
	}

	connectSocket();
	registerControls();
}

function connectSocket() {
	const protocol = window.location.protocol === 'https:' ? 'wss' : 'ws';
	socket = new WebSocket(`${protocol}://${window.location.host}/ws`);

	socket.addEventListener('open', () => {
		sendToSocket({ type: 'auth', token: session.token });
	});

	socket.addEventListener('message', async (event) => {
		let payload;
		try {
			payload = JSON.parse(event.data);
		} catch (error) {
			return;
		}

		switch (payload.type) {
			case 'auth-success':
				handleAuthSuccess(payload);
				break;
			case 'auth-denied': {
				const reason = payload.reason;
				const message = reason === 'meeting-full'
					? 'Meeting is full. Please try again later.'
					: 'Session expired. Please sign in again.';
				alert(message);
				teardown();
				clearSession();
				window.location.replace('/');
				break;
			}
			case 'forced-disconnect':
				alert('Session expired. Please sign in again.');
				teardown();
				clearSession();
				window.location.replace('/');
				break;
			case 'peer-joined':
				handlePeerJoined(payload.user);
				break;
			case 'peer-left':
				handlePeerLeft(payload.user);
				break;
			case 'webrtc-offer':
				await handleOffer(payload.from, payload.payload);
				break;
			case 'webrtc-answer':
				await handleAnswer(payload.from, payload.payload);
				break;
			case 'ice-candidate':
				await handleIceCandidate(payload.from, payload.payload);
				break;
			case 'screen-share-start':
				handleScreenShareStart(payload.user);
				break;
			case 'screen-share-stop':
				handleScreenShareStop(payload.user);
				break;
			case 'screen-share-denied':
				if (payload.owner && payload.owner !== localUser) {
					alert(`Screen is currently shared by ${labelFor(payload.owner)}.`);
				}
				stopScreenShare(true);
				break;
			case 'error':
				console.error('Signaling error:', payload.error);
				break;
			default:
				break;
		}
	});

	socket.addEventListener('close', () => {
		if (state.shuttingDown) {
			return;
		}
		alert('Connection closed. You have been signed out.');
		teardown();
		clearSession();
		window.location.replace('/');
	});
}

function assignSlotFor(user) {
	if (slotByUser.has(user)) {
		return slotByUser.get(user);
	}

	const slot = slots.find((item) => item.user === null);
	if (!slot) {
		console.warn('No available seat for user', user);
		return null;
	}

	slot.user = user;
	slotByUser.set(user, slot);
	slot.name.textContent = labelFor(user);
	slot.placeholder.textContent = labelFor(user).toUpperCase();
	slot.placeholder.style.display = 'flex';
	slot.status.classList.add('offline');
	slot.element.classList.add('offline');
	return slot;
}

function releaseSlotFor(user) {
	const slot = slotByUser.get(user);
	if (!slot) {
		return;
	}

	slot.video.srcObject = null;
	slot.placeholder.style.display = 'flex';
	slot.placeholder.textContent = 'Seat open';
	slot.name.textContent = 'Seat available';
	slot.status.classList.add('offline');
	slot.element.classList.add('offline');
	slot.user = null;
	slotByUser.delete(user);
	remoteStreams.delete(user);
	updatePeek();
}

function setParticipantOnline(user, online) {
	const slot = assignSlotFor(user);
	if (!slot) {
		return;
	}
	slot.element.classList.toggle('offline', !online);
	slot.status.classList.toggle('offline', !online);

	if (!online) {
		slot.video.srcObject = null;
		slot.placeholder.style.display = 'flex';
		remoteStreams.delete(user);
		updatePeek();
	}
}

async function initLocalMedia() {
	localStream = await navigator.mediaDevices.getUserMedia({
		audio: {
			echoCancellation: true,
			noiseSuppression: true,
			autoGainControl: false
		},
		video: {
			width: { ideal: 1280 },
			height: { ideal: 720 },
			frameRate: { ideal: CAMERA_MAX_FPS, max: CAMERA_MAX_FPS }
		}
	});

	const cameraTrack = localStream.getVideoTracks()[0];
	if (cameraTrack) {
		setTrackContentHint(cameraTrack, 'motion');
		void applyTrackFrameRate(cameraTrack, CAMERA_MAX_FPS);
	}
}

function attachLocalPreview(user) {
	const slot = assignSlotFor(user);
	if (!slot) {
		return;
	}
	slot.video.srcObject = localStream;
	slot.video.muted = true;
	slot.video.play().catch(() => {});
	slot.placeholder.style.display = state.videoEnabled ? 'none' : 'flex';
	slot.placeholder.textContent = labelFor(user).toUpperCase();
	setParticipantOnline(user, true);
}

function sendToSocket(message) {
	if (!socket || socket.readyState !== WebSocket.OPEN) {
		return;
	}
	socket.send(JSON.stringify(message));
}

function registerControls() {
	toggleAudioBtn.addEventListener('click', () => {
		state.audioEnabled = !state.audioEnabled;
		localStream.getAudioTracks().forEach((track) => {
			track.enabled = state.audioEnabled;
		});
		toggleAudioBtn.textContent = state.audioEnabled ? 'Mute' : 'Unmute';
		toggleAudioBtn.classList.toggle('active', !state.audioEnabled);
	});

	toggleVideoBtn.addEventListener('click', () => {
		state.videoEnabled = !state.videoEnabled;
		localStream.getVideoTracks().forEach((track) => {
			track.enabled = state.videoEnabled;
		});
		toggleVideoBtn.textContent = state.videoEnabled ? 'Stop Camera' : 'Start Camera';
		toggleVideoBtn.classList.toggle('active', !state.videoEnabled);
		updateLocalPlaceholder();
	});

	if (toggleFullscreenBtn) {
		if (!fullscreenSupport) {
			toggleFullscreenBtn.style.display = 'none';
		} else {
			toggleFullscreenBtn.addEventListener('click', () => {
			if (isFullscreenActive()) {
				exitFullscreen();
			} else {
				enterFullscreen();
			}
			updateFullscreenButton();
		});
			document.addEventListener('fullscreenchange', updateFullscreenButton);
			document.addEventListener('webkitfullscreenchange', updateFullscreenButton);
			document.addEventListener('msfullscreenchange', updateFullscreenButton);
			updateFullscreenButton();
		}
	}

	toggleScreenBtn.addEventListener('click', () => {
		if (state.screenShareActive) {
			stopScreenShare();
		} else {
			startScreenShare();
		}
	});

	leaveBtn.addEventListener('click', () => {
		state.shuttingDown = true;
		if (state.screenShareActive) {
			sendToSocket({ type: 'screen-share-stop' });
		}
		teardown();
		clearSession();
		window.location.replace('/');
	});

	window.addEventListener('beforeunload', () => {
		state.shuttingDown = true;
		if (state.screenShareActive) {
			sendToSocket({ type: 'screen-share-stop' });
		}
		teardown();
	});

	if (overlayEnabled) {
		setupPeekDragging();
	} else {
		hideOverlay();
	}
}

function updateLocalPlaceholder() {
	const slot = slotByUser.get(localUser);
	if (!slot) {
		return;
	}
	slot.placeholder.style.display = state.videoEnabled ? 'none' : 'flex';
}

function isFullscreenActive() {
	return Boolean(
		document.fullscreenElement ||
		document.webkitFullscreenElement ||
		document.msFullscreenElement
	);
}

function enterFullscreen() {
	const target = document.documentElement;
	const request =
		target.requestFullscreen ||
		target.webkitRequestFullscreen ||
		target.msRequestFullscreen;
	if (request) {
		let response;
		try {
			response = request.call(target, { navigationUI: 'hide' });
		} catch (error) {
			response = request.call(target);
		}
		if (response && typeof response.catch === 'function') {
			response.catch(() => {});
		}
	}
}

function exitFullscreen() {
	const exit =
		document.exitFullscreen ||
		document.webkitExitFullscreen ||
		document.msExitFullscreen;
	if (exit) {
		const response = exit.call(document);
		if (response && typeof response.catch === 'function') {
			response.catch(() => {});
		}
	}
}

function updateFullscreenButton() {
	if (!toggleFullscreenBtn || !fullscreenSupport) {
		return;
	}
	const active = isFullscreenActive();
	toggleFullscreenBtn.textContent = active ? 'Exit Fullscreen' : 'Enter Fullscreen';
	toggleFullscreenBtn.classList.toggle('active', active);
}

function handleAuthSuccess(payload) {
	localUser = payload.user;
	attachLocalPreview(localUser);
	meetingShell.dataset.state = 'ready';

	const peers = payload.peers || [];
	for (const user of peers) {
		if (slotByUser.size >= MAX_PARTICIPANTS && !slotByUser.has(user)) {
			console.warn('Unable to seat peer due to capacity', user);
			continue;
		}
		setParticipantOnline(user, true);
		ensurePeerConnection(user);
	}

	if (payload.screenSharer) {
		handleScreenShareStart(payload.screenSharer);
	}

	updatePeek();
}

function handlePeerJoined(user) {
	if (user === localUser) {
		return;
	}
	if (slotByUser.size >= MAX_PARTICIPANTS && !slotByUser.has(user)) {
		console.warn('Seat capacity reached; ignoring additional peer', user);
		return;
	}
	setParticipantOnline(user, true);
	const peerState = ensurePeerConnection(user);
	if (!peerState.polite) {
		peerState.pc.onnegotiationneeded?.();
	}
	updatePeek();
}

function handlePeerLeft(user) {
	if (user === localUser) {
		return;
	}
 	clearPeerRecovery(user);
	setParticipantOnline(user, false);
	releaseSlotFor(user);
	const peerState = peerConnections.get(user);
	if (peerState) {
		peerState.pc.close();
		peerConnections.delete(user);
	}
	screenSenders.delete(user);
	if (state.activeScreenSharer === user) {
		handleScreenShareStop(user);
	}
}

function ensurePeerConnection(user) {
	let peerState = peerConnections.get(user);
	if (peerState) {
		return peerState;
	}

	assignSlotFor(user);

	const pc = new RTCPeerConnection({
		iceServers: [{ urls: 'stun:stun.l.google.com:19302' }],
		bundlePolicy: 'max-bundle'
	});

	peerState = {
		pc,
		polite: localUser < user,
		makingOffer: false,
		ignoreOffer: false,
		isSettingRemoteAnswerPending: false
	};
	peerConnections.set(user, peerState);

	pc.onconnectionstatechange = () => {
		switch (pc.connectionState) {
			case 'connected':
			case 'completed':
				clearPeerRecovery(user);
				break;
			case 'disconnected':
				schedulePeerRecovery(user, () => {
					attemptIceRestart(user);
				});
				break;
			case 'failed':
				attemptIceRestart(user);
				schedulePeerRecovery(user, () => {
					if (peerConnections.has(user)) {
						handlePeerLeft(user);
					}
				});
				break;
			case 'closed':
				clearPeerRecovery(user);
				if (peerConnections.has(user)) {
					handlePeerLeft(user);
				}
				break;
			default:
				break;
		}
	};

	pc.oniceconnectionstatechange = () => {
		if (pc.iceConnectionState === 'checking') {
			return;
		}
		if (pc.iceConnectionState === 'failed') {
			attemptIceRestart(user);
		}
	};

	pc.onicecandidate = ({ candidate }) => {
		if (!candidate) {
			return;
		}
		sendToSocket({ type: 'ice-candidate', to: user, payload: candidate });
	};

	pc.ontrack = (event) => {
		handleRemoteTrack(user, event);
	};

	pc.onnegotiationneeded = async () => {
		try {
			peerState.makingOffer = true;
			await pc.setLocalDescription(await pc.createOffer());
			sendToSocket({ type: 'webrtc-offer', to: user, payload: pc.localDescription });
		} catch (error) {
			console.error('Negotiation failed:', error);
		} finally {
			peerState.makingOffer = false;
		}
	};

	localStream.getTracks().forEach((track) => {
		const sender = pc.addTrack(track, localStream);
		if (track.kind === 'video') {
			tuneSenderForTrack(sender, track, {
				maxBitrate: CAMERA_MAX_BITRATE,
				maxFramerate: CAMERA_MAX_FPS,
				priority: 'high',
				degradationPreference: 'maintain-framerate',
				contentHint: 'motion'
			});
		} else if (track.kind === 'audio') {
			tuneSenderForTrack(sender, track, {
				maxBitrate: 64000,
				priority: 'high'
			});
		}
	});

	if (state.screenShareActive && screenStream) {
		const senders = screenSenders.get(user) || [];
		screenStream.getTracks().forEach((mediaTrack) => {
			const sender = pc.addTrack(mediaTrack, screenStream);
			if (mediaTrack.kind === 'video') {
				tuneSenderForTrack(sender, mediaTrack, {
					maxBitrate: SCREEN_MAX_BITRATE,
					maxFramerate: SCREEN_MAX_FPS,
					priority: 'high',
					degradationPreference: 'maintain-framerate',
					contentHint: 'motion'
				});
			} else if (mediaTrack.kind === 'audio') {
				tuneSenderForTrack(sender, mediaTrack, {
					maxBitrate: 192000,
					priority: 'high'
				});
			}
			senders.push(sender);
		});
		screenSenders.set(user, senders);
	}

	return peerState;
}

function handleRemoteTrack(user, event) {
	const stream = event.streams && event.streams[0];
	if (!stream) {
		return;
	}

	if (event.track.kind === 'video' && state.activeScreenSharer === user && user !== localUser) {
		screenVideo.srcObject = stream;
		screenVideo.muted = false;
		screenVideo.play().catch(() => {});
		screenPlaceholder.style.display = 'none';
		screenIndicator.textContent = `${labelFor(user)} is sharing`;
		screenIndicator.classList.add('visible');
		return;
	}

	const slot = assignSlotFor(user);
	if (!slot) {
		return;
	}

	if (!slot.video.srcObject) {
		slot.video.srcObject = stream;
	}
	slot.video.muted = user === localUser;
	slot.video.play().catch(() => {});

	if (event.track.kind === 'video') {
		slot.placeholder.style.display = 'none';
		remoteStreams.set(user, stream);
		updatePeek();

		event.track.onended = () => {
			slot.placeholder.style.display = 'flex';
			remoteStreams.delete(user);
			updatePeek();
		};
		event.track.onmute = () => {
			slot.placeholder.style.display = 'flex';
			remoteStreams.delete(user);
			updatePeek();
		};
		event.track.onunmute = () => {
			slot.placeholder.style.display = 'none';
			remoteStreams.set(user, stream);
			updatePeek();
		};
	}
}

async function handleOffer(from, description) {
	const peerState = ensurePeerConnection(from);
	const pc = peerState.pc;
	const offer = new RTCSessionDescription(description);
	const readyForOffer = !peerState.makingOffer && (pc.signalingState === 'stable' || peerState.isSettingRemoteAnswerPending);
	const offerCollision = !readyForOffer;

	peerState.ignoreOffer = !peerState.polite && offerCollision;
	if (peerState.ignoreOffer) {
		return;
	}

	try {
		peerState.isSettingRemoteAnswerPending = offer.type === 'offer';
		await pc.setRemoteDescription(offer);
		peerState.isSettingRemoteAnswerPending = false;
		await pc.setLocalDescription(await pc.createAnswer());
		sendToSocket({ type: 'webrtc-answer', to: from, payload: pc.localDescription });
	} catch (error) {
		console.error('Offer handling failed:', error);
	}
}

async function handleAnswer(from, description) {
	const peerState = peerConnections.get(from);
	if (!peerState) {
		return;
	}
	try {
		await peerState.pc.setRemoteDescription(new RTCSessionDescription(description));
	} catch (error) {
		console.error('Answer handling failed:', error);
	}
}

async function handleIceCandidate(from, candidate) {
	const peerState = peerConnections.get(from);
	if (!peerState) {
		return;
	}
	try {
		await peerState.pc.addIceCandidate(candidate);
	} catch (error) {
		console.error('ICE candidate failed:', error);
	}
}

async function acquireScreenMedia() {
	const videoConstraints = {
		frameRate: { ideal: 40, max: 60 }
	};

	const audioConstraints = {
		echoCancellation: false,
		noiseSuppression: false,
		autoGainControl: false,
		channelCount: 2,
		sampleRate: 48000,
		systemAudio: 'include',
		selfBrowserSurface: 'exclude',
		suppressLocalAudioPlayback: true
	};

	try {
		return await navigator.mediaDevices.getDisplayMedia({
			video: videoConstraints,
			audio: audioConstraints
		});
	} catch (error) {
		if (error && (error.name === 'NotAllowedError' || error.name === 'AbortError')) {
			throw error;
		}
		console.warn('System audio share not available, retrying without audio:', error);
		alert('System audio is not available with your current browser share. Continuing without audio.');
		return navigator.mediaDevices.getDisplayMedia({
			video: videoConstraints,
			audio: false
		});
	}
}

async function startScreenShare() {
	if (state.screenShareActive) {
		return;
	}

	try {
		screenStream = await acquireScreenMedia();
	} catch (error) {
		console.warn('Screen share failed:', error);
		return;
	}

	const primaryVideoTrack = screenStream.getVideoTracks()[0];
	if (!primaryVideoTrack) {
		screenStream.getTracks().forEach((mediaTrack) => mediaTrack.stop());
		screenStream = null;
		alert('Screen share requires a video track. Please try again.');
		return;
	}

	setTrackContentHint(primaryVideoTrack, 'motion');
	void applyTrackFrameRate(primaryVideoTrack, SCREEN_MAX_FPS);

	const screenAudioTrack = screenStream.getAudioTracks()[0];
	if (screenAudioTrack) {
		setTrackContentHint(screenAudioTrack, 'detail');
	}

	primaryVideoTrack.addEventListener('ended', () => {
		stopScreenShare();
	});

	pipSuppressed = false;
	state.screenShareActive = true;
	state.activeScreenSharer = localUser;
	if (meetingShell) {
		meetingShell.dataset.presenting = 'true';
	}
	screenVideo.srcObject = screenStream;
	screenVideo.muted = true;
	screenVideo.play().catch(() => {});
	screenPlaceholder.style.display = 'none';
	screenIndicator.textContent = 'You are sharing';
	screenIndicator.classList.add('visible');
	toggleScreenBtn.textContent = 'Stop Sharing';
	toggleScreenBtn.classList.add('active');

	for (const [user, peerState] of peerConnections) {
		const senders = screenSenders.get(user) || [];
		screenStream.getTracks().forEach((mediaTrack) => {
			const sender = peerState.pc.addTrack(mediaTrack, screenStream);
			if (mediaTrack.kind === 'video') {
				tuneSenderForTrack(sender, mediaTrack, {
					maxBitrate: SCREEN_MAX_BITRATE,
					maxFramerate: SCREEN_MAX_FPS,
					priority: 'high',
					degradationPreference: 'maintain-framerate',
					contentHint: 'motion'
				});
			} else if (mediaTrack.kind === 'audio') {
				tuneSenderForTrack(sender, mediaTrack, {
					maxBitrate: 192000,
					priority: 'high'
				});
			}
			senders.push(sender);
		});
		screenSenders.set(user, senders);
	}

	sendToSocket({ type: 'screen-share-start' });
	updatePeek();
}

function stopScreenShare(silent) {
	if (!state.screenShareActive) {
		return;
	}

	state.screenShareActive = false;
	if (meetingShell) {
		delete meetingShell.dataset.presenting;
	}
	closePipWindow();
	pipSuppressed = false;

	for (const [user, senders] of screenSenders) {
		const peerState = peerConnections.get(user);
		if (!peerState) {
			continue;
		}
		senders.forEach((sender) => {
			try {
				peerState.pc.removeTrack(sender);
			} catch (error) {
				console.warn('Failed to remove screen sender:', error);
			}
		});
	}
	screenSenders.clear();

	if (screenStream) {
		screenStream.getTracks().forEach((track) => track.stop());
		screenStream = null;
	}

	if (!silent) {
		sendToSocket({ type: 'screen-share-stop' });
	}

	if (state.activeScreenSharer === localUser) {
		state.activeScreenSharer = null;
	}

	screenVideo.srcObject = null;
	screenVideo.muted = false;
	screenPlaceholder.style.display = 'block';
	screenIndicator.classList.remove('visible');
	toggleScreenBtn.textContent = 'Share Screen';
	toggleScreenBtn.classList.remove('active');
	updatePeek();
}

function handleScreenShareStart(user) {
	state.activeScreenSharer = user;
	if (user === localUser) {
		screenIndicator.textContent = 'You are sharing';
		screenIndicator.classList.add('visible');
	} else {
		screenIndicator.textContent = `${labelFor(user)} is sharing`;
		screenIndicator.classList.add('visible');
		screenPlaceholder.style.display = 'none';
	}
	updatePeek();
}

function handleScreenShareStop(user) {
	if (state.activeScreenSharer !== user) {
		return;
	}
	state.activeScreenSharer = null;

	if (user !== localUser) {
		screenVideo.srcObject = null;
	}

	if (!state.screenShareActive) {
		screenPlaceholder.style.display = 'block';
		screenIndicator.classList.remove('visible');
	}
	updatePeek();
}

function updatePeek() {
	const isLocalSharer = state.screenShareActive && state.activeScreenSharer === localUser;
	if (!isLocalSharer) {
		closePipWindow();
		renderOverlay([], false);
		return;
	}

	const participants = collectPeekParticipants();
	if (supportsDocumentPiP && !pipSuppressed) {
		renderOverlay([], false);
		void renderPipWindow(participants).catch((error) => {
			console.warn('Document PiP update failed:', error);
			pipSuppressed = true;
			closePipWindow({ suppress: true });
			renderOverlay(participants, true);
		});
	} else {
		renderOverlay(participants, true);
	}
}

function collectPeekParticipants() {
	const participants = [];
	if (localUser) {
		const localVideoActive = Boolean(
			localStream?.getVideoTracks().some((track) => track.readyState === 'live' && track.enabled)
		);
		participants.push({
			user: localUser,
			label: labelFor(localUser),
			stream: localVideoActive ? localStream : null,
			hasVideo: localVideoActive
		});
	}

	for (const user of slotByUser.keys()) {
		if (user === localUser) {
			continue;
		}
		const stream = remoteStreams.get(user) || null;
		participants.push({
			user,
			label: labelFor(user),
			stream,
			hasVideo: Boolean(stream)
		});
	}

	return participants.slice(0, MAX_PARTICIPANTS);
}

function renderOverlay(participants, shouldShow) {
	if (!shouldShow) {
		sharingPeek.classList.remove('visible');
		sharingPeek.classList.remove('dragging');
		sharingPeek.style.left = '';
		sharingPeek.style.top = '';
		sharingPeek.style.right = '';
		sharingPeek.style.bottom = '';
		sharingPeekEmpty.style.display = 'none';
		sharingPeekGrid.querySelectorAll('video').forEach((video) => {
			video.srcObject = null;
		});
		sharingPeekGrid.innerHTML = '';
		return;
	}

	sharingPeek.classList.add('visible');
	const existingVideos = sharingPeekGrid.querySelectorAll('video');
	existingVideos.forEach((video) => {
		video.srcObject = null;
	});
	sharingPeekGrid.innerHTML = '';

	participants.forEach((participant) => {
		const tile = document.createElement('div');
		tile.className = 'peek-tile';
		tile.dataset.user = participant.user;

		const videoShell = document.createElement('div');
		videoShell.className = 'peek-video';
		const video = document.createElement('video');
		video.autoplay = true;
		video.playsInline = true;
		video.muted = true;
		video.dataset.user = participant.user;

		const placeholder = document.createElement('div');
		placeholder.className = 'peek-placeholder';
		placeholder.textContent = participant.label.slice(0, 2).toUpperCase();

		if (participant.stream) {
			video.srcObject = participant.stream;
			video.play().catch(() => {});
			video.style.display = 'block';
			placeholder.style.display = 'none';
		} else {
			video.style.display = 'none';
			placeholder.style.display = 'flex';
		}

		videoShell.appendChild(video);
		videoShell.appendChild(placeholder);
		tile.appendChild(videoShell);

		const label = document.createElement('div');
		label.className = 'peek-label';
		label.textContent = participant.label;
		tile.appendChild(label);

		sharingPeekGrid.appendChild(tile);
	});

	const remotePresent = participants.some((participant) => participant.user !== localUser);
	sharingPeekEmpty.style.display = remotePresent ? 'none' : 'block';
}

async function renderPipWindow(participants) {
	const pip = await ensurePipWindow();
	if (!pip || !pipRoot || !pipEmptyMessage) {
		throw new Error('Picture-in-Picture window unavailable');
	}

	const doc = pip.document;
	const existingTiles = new Map(
		Array.from(pipRoot.querySelectorAll('[data-user]')).map((tile) => [tile.dataset.user, tile])
	);
	const activeUsers = new Set(participants.map((participant) => participant.user));

	for (const [user, tile] of existingTiles) {
		if (!activeUsers.has(user)) {
			const video = tile.querySelector('video');
			if (video) {
				video.srcObject = null;
			}
			tile.remove();
			existingTiles.delete(user);
		}
	}

	participants.forEach((participant) => {
		let tile = existingTiles.get(participant.user);
		if (!tile) {
			tile = doc.createElement('div');
			tile.className = 'pip-tile';
			tile.dataset.user = participant.user;
			tile.innerHTML = `
				<div class="pip-video">
					<video muted autoplay playsinline></video>
					<div class="pip-placeholder"></div>
				</div>
				<div class="pip-label"></div>
			`;
			pipRoot.appendChild(tile);
			existingTiles.set(participant.user, tile);
		}

		const video = tile.querySelector('video');
		const placeholder = tile.querySelector('.pip-placeholder');
		const label = tile.querySelector('.pip-label');
		label.textContent = participant.label;

		if (participant.stream) {
			if (video.srcObject !== participant.stream) {
				video.srcObject = participant.stream;
				video.play().catch(() => {});
			}
			video.style.display = 'block';
			placeholder.style.display = 'none';
		} else {
			video.srcObject = null;
			video.style.display = 'none';
			placeholder.textContent = participant.label.slice(0, 2).toUpperCase();
			placeholder.style.display = 'flex';
		}
	});

	const remotePresent = participants.some((participant) => participant.user !== localUser);
	pipEmptyMessage.style.display = remotePresent ? 'none' : 'flex';
	doc.body.classList.toggle('pip-empty', !remotePresent);
}

async function ensurePipWindow() {
	if (!supportsDocumentPiP) {
		return null;
	}
	if (pipWindow && !pipWindow.closed) {
		return pipWindow;
	}

	try {
		pipWindow = await window.documentPictureInPicture.requestWindow({ width: 320, height: 220 });
	} catch (error) {
		pipWindow = null;
		throw error;
	}

	const doc = pipWindow.document;
	const style = doc.createElement('style');
	style.textContent = `
		:root {
			color-scheme: dark;
			font-family: "SF Pro Display", "SF Pro Text", -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
		}
		body {
			margin: 0;
			padding: 0.65rem 0.75rem 0.75rem;
			background: rgba(12, 16, 34, 0.92);
			color: #f8fafc;
			min-height: 100%;
			box-sizing: border-box;
		}
		body, body * {
			user-select: none;
		}
		.pip-root {
			display: grid;
			gap: 0.6rem;
			grid-template-columns: repeat(auto-fit, minmax(96px, 1fr));
		}
		.pip-tile {
			display: flex;
			flex-direction: column;
			gap: 0.4rem;
			padding: 0.35rem;
			border-radius: 16px;
			background: rgba(22, 24, 46, 0.8);
			border: 1px solid rgba(148, 163, 184, 0.16);
			box-shadow: 0 18px 45px rgba(10, 12, 32, 0.45);
		}
		.pip-video {
			position: relative;
			border-radius: 12px;
			overflow: hidden;
			background: rgba(8, 9, 22, 0.86);
			aspect-ratio: 4 / 3;
		}
		.pip-video video {
			width: 100%;
			height: 100%;
			object-fit: cover;
		}
		.pip-placeholder {
			position: absolute;
			inset: 0;
			display: flex;
			align-items: center;
			justify-content: center;
			font-weight: 600;
			letter-spacing: 0.08em;
			color: rgba(248, 250, 252, 0.72);
			text-transform: uppercase;
			background: rgba(12, 15, 32, 0.62);
		}
		.pip-label {
			font-size: 0.78rem;
			letter-spacing: 0.05em;
			color: rgba(248, 250, 252, 0.65);
		}
		.pip-empty-message {
			margin: 0.4rem 0;
			padding: 0.6rem 0.5rem;
			border-radius: 12px;
			border: 1px dashed rgba(148, 163, 184, 0.35);
			background: rgba(15, 18, 36, 0.8);
			font-size: 0.82rem;
			letter-spacing: 0.05em;
			color: rgba(248, 250, 252, 0.65);
			text-align: center;
			display: none;
		}
		body.pip-empty .pip-empty-message {
			display: flex;
			align-items: center;
			justify-content: center;
		}
	`;
	doc.head.appendChild(style);

	doc.body.innerHTML = `
		<div id="pip-root" class="pip-root"></div>
		<div id="pip-empty" class="pip-empty-message">Waiting for other participants…</div>
	`;

	pipRoot = doc.getElementById('pip-root');
	pipEmptyMessage = doc.getElementById('pip-empty');

	pipWindow.addEventListener('pagehide', () => {
		const stillSharing = state.screenShareActive && state.activeScreenSharer === localUser;
		pipWindow = null;
		pipRoot = null;
		pipEmptyMessage = null;
		if (!pipClosing && stillSharing) {
			pipSuppressed = true;
			renderOverlay(collectPeekParticipants(), true);
		}
		pipClosing = false;
	});

	return pipWindow;
}

function closePipWindow(options = {}) {
	const { suppress = false } = options;
	if (!pipWindow) {
		if (!suppress) {
			pipSuppressed = false;
		}
		return;
	}

	pipClosing = true;
	try {
		pipWindow.close();
	} catch (error) {
		console.warn('Failed to close PiP window:', error);
		pipClosing = false;
		pipWindow = null;
		pipRoot = null;
		pipEmptyMessage = null;
	}

	if (!suppress) {
		pipSuppressed = false;
	}
}

function setupPeekDragging() {
	let dragState = null;

	const endDrag = (event) => {
		if (!dragState || event.pointerId !== dragState.pointerId) {
			return;
		}
		if (sharingPeekHeader.hasPointerCapture(event.pointerId)) {
			sharingPeekHeader.releasePointerCapture(event.pointerId);
		}
		dragState = null;
		sharingPeek.classList.remove('dragging');
	};

	sharingPeekHeader.addEventListener('pointerdown', (event) => {
		if (!sharingPeek.classList.contains('visible')) {
			return;
		}
		event.preventDefault();
		const rect = sharingPeek.getBoundingClientRect();
		dragState = {
			pointerId: event.pointerId,
			offsetX: event.clientX - rect.left,
			offsetY: event.clientY - rect.top
		};
		sharingPeekHeader.setPointerCapture(event.pointerId);
		sharingPeek.classList.add('dragging');
	});

	sharingPeekHeader.addEventListener('pointermove', (event) => {
		if (!dragState || event.pointerId !== dragState.pointerId) {
			return;
		}
		const width = sharingPeek.offsetWidth;
		const height = sharingPeek.offsetHeight;
		const left = event.clientX - dragState.offsetX;
		const top = event.clientY - dragState.offsetY;
		const maxLeft = Math.max(0, window.innerWidth - width);
		const maxTop = Math.max(0, window.innerHeight - height);
		const clampedLeft = Math.min(Math.max(0, left), maxLeft);
		const clampedTop = Math.min(Math.max(0, top), maxTop);
		sharingPeek.style.left = `${clampedLeft}px`;
		sharingPeek.style.top = `${clampedTop}px`;
		sharingPeek.style.right = 'auto';
		sharingPeek.style.bottom = 'auto';
	});

	sharingPeekHeader.addEventListener('pointerup', endDrag);
	sharingPeekHeader.addEventListener('pointercancel', endDrag);
}

function teardown() {
	if (screenStream) {
		screenStream.getTracks().forEach((track) => track.stop());
		screenStream = null;
	}

	if (localStream) {
		localStream.getTracks().forEach((track) => track.stop());
		localStream = null;
	}

	closePipWindow();
	pipSuppressed = false;

	if (fullscreenSupport && isFullscreenActive()) {
		exitFullscreen();
		updateFullscreenButton();
	}

	for (const peerState of peerConnections.values()) {
		peerState.pc.close();
	}
	peerConnections.clear();
	screenSenders.clear();

	const occupants = Array.from(slotByUser.keys());
	occupants.forEach((user) => releaseSlotFor(user));

	if (socket && socket.readyState === WebSocket.OPEN) {
		socket.close();
	}

	updatePeek();
}
