const STORAGE_KEY = 'tricall.session';

function getStoredSession() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY));
  } catch (error) {
    return null;
  }
}

function rememberSession(payload) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({
    token: payload.token,
    username: payload.username,
    label: payload.label,
    timestamp: Date.now()
  }));
}

function clearSession() {
  localStorage.removeItem(STORAGE_KEY);
}

const form = document.getElementById('login-form');
const usernameField = document.getElementById('username');
const passwordField = document.getElementById('password');
const errorBanner = document.getElementById('error');

const existingSession = getStoredSession();
if (existingSession?.username) {
  usernameField.value = existingSession.username;
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  errorBanner.classList.remove('visible');

  const username = usernameField.value.trim().toLowerCase();
  const password = passwordField.value;

  try {
    const response = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, password })
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({ error: 'Login failed' }));
      throw new Error(error.error || 'Login failed');
    }

    const payload = await response.json();
    rememberSession(payload);
    passwordField.value = '';
    window.location.href = '/meeting.html';
  } catch (error) {
    clearSession();
    errorBanner.textContent = error.message || 'Could not log in';
    errorBanner.classList.add('visible');
  }
});
